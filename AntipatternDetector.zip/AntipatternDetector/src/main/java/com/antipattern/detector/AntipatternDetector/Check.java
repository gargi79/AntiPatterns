package com.antipattern.detector.AntipatternDetector;

//package CodeSmell;

public class Check {
	
	public String AA(){
		String x = "hi";
		return x;
	}
	public String AB(){
		String x = "hi";
		return x;
	}
	public String AC(){
		String x = "hi";
		return x;
	}
	public String AD(){
		String x = "hi";
		return x;
	}
	public String AE(){
		String x = "hi";
		return x;
	}
	
	
}